var searchData=
[
  ['value_5fptr',['value_ptr',['../a00178.html#gaf019636bb8bd7c9efb7c7ce3bb23bcfc',1,'glm']]]
];
